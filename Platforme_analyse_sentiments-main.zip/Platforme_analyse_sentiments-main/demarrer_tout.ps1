Write-Host "?? D�marrage de la plateforme d'analyse de sentiments..." -ForegroundColor Cyan

# 1. D�marrer Docker Compose
Write-Host "?? D�marrage des conteneurs Docker..." -ForegroundColor Yellow
docker-compose up -d

# 2. Attendre que les services soient pr�ts
Write-Host "? Attente du d�marrage des services..." -ForegroundColor Yellow
Start-Sleep -Seconds 10

# 3. V�rifier l'�tat
Write-Host "`n?? �tat des services:" -ForegroundColor Cyan
docker-compose ps

# 4. Ouvrir les URLs
Write-Host "`n?? URLs disponibles:" -ForegroundColor Cyan
Write-Host "   API Backend: http://localhost:8002" -ForegroundColor Green
Write-Host "   Frontend: http://localhost:3000" -ForegroundColor Green
Write-Host "   Minio Console: http://localhost:9001" -ForegroundColor Green
Write-Host "   PostgreSQL: localhost:5432" -ForegroundColor Green
Write-Host "   Redis: localhost:6379" -ForegroundColor Green

# 5. D�marrer le worker
Write-Host "`n?? D�marrage du Worker..." -ForegroundColor Yellow
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd 'D:\venvs\pyscaffold_env\Platforme_analyse_sentiments'; Write-Host 'Worker - Analyse de sentiments' -ForegroundColor Cyan; `$env:REDIS_HOST='localhost'; `$env:DB_HOST='localhost'; python worker.py"

Write-Host "`n? Tous les services sont d�marr�s !" -ForegroundColor Green
Write-Host "?? Pour arr�ter, ex�cutez: docker-compose down" -ForegroundColor Yellow
